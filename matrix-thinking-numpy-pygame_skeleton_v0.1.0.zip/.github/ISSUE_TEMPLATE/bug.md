---
name: Bug Report
about: Something isn't working
---
**Steps to reproduce**
**Expected**
**Actual**
**Screenshots/logs**
**Environment (OS, Python)**
