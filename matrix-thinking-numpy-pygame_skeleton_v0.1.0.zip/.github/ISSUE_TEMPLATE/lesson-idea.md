---
name: Lesson Idea
about: Propose an activity or exercise
---
**Idea summary**
**Learning goal**
**Student steps**
**Materials needed**
