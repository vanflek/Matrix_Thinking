# Changelog

## v0.1.0
- Initial lesson skeleton (0/1 matrix → tiles with double loop)
- Teacher pack (RU/EN), printables, pixel‑art examples
