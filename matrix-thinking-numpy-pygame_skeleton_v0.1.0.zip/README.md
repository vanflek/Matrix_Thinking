# Matrix Thinking — Lesson 1 (NumPy × Pygame)

A classroom-friendly starter that turns a **0/1 matrix** into a **tile picture** using **NumPy** (data) and **Pygame** (rendering).
This repo includes a teacher pack (RU/EN), printables, and student-ready pixel-art examples.

## Why this helps students
- Links **tables** to **graphics**: “axes → cell → rule → picture”
- Immediate feedback: change data → see the result
- Builds foundations for vectorization, RGB as vectors, and later kernels

## Quickstart
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/lesson01_skeleton.py
```

## Lesson 1 outline (80 minutes)
- Create a small matrix (0/1) · Traverse with a double loop · Change one cell and a block (slice) · Visualize as tiles
- Student authorship: 16×16 pixel‑art or 1–2 letters + a short “how it’s made” (rows/cols/blocks)

## Downloads
- See `lessons/01-matrix-basics/teacher-pack/` (RU/EN PDFs) and `printables/`

## License
- Code: MIT (see `LICENSE`)
- Educational materials: CC BY 4.0 (see `LICENSE-docs`)
