# Matrix Thinking — Lesson 1

**NumPy × Pygame** starter for K‑12.  
Downloads: see the [teacher-pack](../lessons/01-matrix-basics/teacher-pack/) and [printables](../lessons/01-matrix-basics/printables/).

Latest release available on the Releases page.
