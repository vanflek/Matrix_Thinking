import pygame
import numpy

pygame.init()
#matrix
ROWS, COLS = 16, 32
screen_matrix = numpy.zeros((ROWS, COLS), dtype=numpy.uint8)
#screen
TILE_SIZE = 32
TILE_X, TILE_Y = COLS, ROWS
WIDTH, HEIGHT = TILE_SIZE * TILE_X, TILE_SIZE * TILE_Y
screen = pygame.display.set_mode((WIDTH, HEIGHT))
#colors
BLACK = numpy.array((0, 0, 0))
WHITE = numpy.array((255, 255, 255))
RED = numpy.array((255, 0, 0))

FPS = 60
clock = pygame.time.Clock()

run = True
while run:
    #events control
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    #drawing
    for y in range(ROWS):
        for x in range(COLS):
            if screen_matrix[y][x] == 0:
                pygame.draw.rect(screen, BLACK, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            else:
                pygame.draw.rect(screen, WHITE, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            pygame.draw.rect(screen, RED, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)
    pygame.display.update()
    clock.tick(FPS)
pygame.quit()
